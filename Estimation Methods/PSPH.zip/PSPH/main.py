import time
import numpy as np
import sys
from editdistance import *
import cProfile
from like import *


def g_mean(list_):
    """
    Computes the geometric mean of a list of numbers via the log-mean-exp
    trick (mean of logs, then exponentiate back).

    Args:
        list_: sequence of positive numbers.

    Returns:
        The geometric mean as a float.
    """
    log_list_ = np.log(list_)
    return np.exp(log_list_.mean())


def match(filename):
    """
    Parses a fixed-width histogram text file (as written by an earlier
    `draw()`-style function, with a header starting with "End" and a
    separator line starting with "---") into a dictionary.

    For each non-header/non-separator line, splits on runs of 14 spaces
    into three columns (a, b, c), extracts the endpoint pattern from
    column b by stripping out spaces, collapses a literal "%0%" segment
    if present, and stores the pattern as a key mapped to the integer
    parsed from column c starting at character index 9 (skipping a fixed
    label prefix in that column).

    Args:
        filename: path to the histogram file to parse.

    Returns:
        dict mapping pattern string -> integer endpoint count.
    """
    dict = {}
    for i in open(filename):
        liste = []
        if i.startswith("End") or i.startswith("---"):
            pass
        else:
            a, b, c = i.split("              ")
            for i in b:
                if i != " ":
                    liste.append(i)
            newliste = list("".join(liste))
            str = "".join(newliste)
            if "%0%" in str:
                str = str.replace("%0%", "")
            if str not in dict:
                dict[str] = int(c[9:])
    return dict


def allprefixes(new):
    """
    Builds a list of prefix/suffix string pairs for `new`, for every
    split position n from 1 up to (but not including) len(new), using
    indexing() to produce each (suffix, prefix) pair.

    Args:
        new: the input pattern string.

    Returns:
        A flat list alternating [suffix_1, prefix_1, suffix_2, prefix_2,
        ...] for each split position, as produced by indexing().
    """
    n = 1
    liste = []
    while n < len(new):
        str1 = indexing(new, n)[0]
        str2 = indexing(new, n)[1]
        liste.append(str1)
        liste.append(str2)
        n += 1
    return liste


def indexing(string, n):
    """
    Strips all "%" characters from `string`, then splits it at position
    n into a (suffix, prefix) pair.

    Args:
        string: the input string (may contain "%" wildcard characters,
            which are removed before splitting).
        n: the split position.

    Returns:
        Tuple (string[n:], string[:n]) computed on the "%"-stripped
        string.
    """
    string = string.replace("%", "")
    string1 = string[n:]
    string2 = string[:n]
    return string1, string2


def divide_two(string, n):
    """
    Splits `string` into two overlapping substrings of the same length,
    offset by one position: one starting at index n, and one starting at
    index n-1, both extending to (but not including) the same relative
    end offset.

    Args:
        string: the input string.
        n: the offset controlling where each substring starts.

    Returns:
        Tuple (string[n:length], string[n-1:length-1]) where length is
        len(string).
    """
    length = len(string)
    string1 = string[n:length]
    string2 = string[n - 1:length - 1]
    return string1, string2


def allkmerges(new, n):
    """
    Generates all contiguous substrings ("k-mers") of length n from
    `new`. If `new` is shorter than n, returns `new` itself unchanged as
    the only element.

    Args:
        new: the input string.
        n: the desired substring length.

    Returns:
        List of all length-n contiguous substrings of `new`, in order,
        or a single-element list containing `new` if len(new) < n.
    """
    liste = []
    if n < len(new):
        for i in range(len(new) - n + 1):
            liste.append(new[i:i + n])
    else:
        liste.append(new)
    return liste


def match2(fil, fil2, minsup, fil3):
    """
    Computes a Q-error-like score for each query pattern in `fil3` by
    matching it against the histogram patterns loaded from `fil` (via
    match()), and writes the results to `fil2`.

    For each line in fil3 (expected format "pattern:true_count"):
      - if the query pattern exactly matches a histogram pattern, the
        score is max(hist_count / true_count, true_count / hist_count);
      - otherwise, for every histogram pattern that LIKE-matches the
        query pattern (via like3()), the running best histogram count is
        tracked and the same max-ratio score is computed against it;
      - if no histogram pattern matches at all, `minsup` is used as the
        fallback count in the same max-ratio score, and a running
        mismatch counter is incremented.

    Also times the per-query matching loop and prints the average time
    per query across all lines in fil3.

    Args:
        fil: path to the histogram file passed to match().
        fil2: output path where "true_count:score" lines are written.
        minsup: fallback count used when a query pattern matches no
            histogram pattern.
        fil3: path to the query file, with lines formatted as
            "pattern:true_count".

    Returns:
        None. Writes results to `fil2` and prints the average per-query
        matching time to stdout.
    """
    file2 = open(fil2, "w")
    a = match(fil)
    dict1 = {}
    dict2 = {}
    count = 0
    newcount = 0
    times = []
    for i in open(fil3):
        newcount += 1
        k = i.strip().split(':')
        dict2[k[0]] = k[-1]
        st = time.time()
        for j in a:
            if k[0] == j:
                dict1[k[0]] = max(a[j] / int(k[-1]), int(k[-1]) / a[j])
            elif like3(k[0], j) == True:
                if k[0] not in dict1:
                    dict1[k[0]] = max(a[j] / int(k[-1]), int(k[-1]) / a[j])
                else:
                    m = max(a[j], dict1[k[0]])
                    dict1[k[0]] = max(m / int(k[-1]), int(k[-1]) / m)
        if k[0] not in dict1:
            count += 1
            dict1[k[0]] = max(minsup / int(k[-1]), int(k[-1]) / minsup)
        times.append(time.time() - st)
    print(sum(times) / len(times))
    for ss in dict1:
        file2.write(dict2[ss] + ':' + str(str(dict1[ss])) + '\n')


match2("histogram.txt", "result.txt", datasetsize, 'test_queries.txt')
