import re


def openfile(filename):
    """
    Reads a file of lines shaped like "[a, b, c]: 123" and builds a
    dictionary mapping a '%'-joined pattern string to its integer count.

    For each line:
      - splits on ":" into the bracketed content (a) and the count (b)
      - strips the surrounding brackets from a, splits its comma-separated
        elements, and joins them with "%"
      - removes literal "%0%" segments (i.e. collapses [a, 0, b] -> "a%b")
      - collapses any run of consecutive "%" characters into a single "%"
      - stores the resulting pattern string as a key with int(b) as the value

    Lines that don't match this shape raise an exception during parsing,
    which is caught and reported (prints 'aaaaaaaaaaa') rather than
    stopping the whole read.

    Args:
        filename: path to the input file.

    Returns:
        dict mapping pattern string -> integer count.
    """
    dicti = {}
    with open(filename) as f:
        for line in f:
            line = line.strip()
            try:
                a, b = line.split(":")
                content = a[1:-1]
                elements = [item.strip() for item in content.split(", ")]
                result = "%".join(elements)
                result = result.replace("%0%", "")  # [a,0,b] -> ab
                result = re.sub(r'%+', '%', result)
                dicti[result] = int(b)
            except:
                print('aaaaaaaaaaa')
    return dicti


def newopen(filename):
    """
    Reads a simpler "key value" per-line file (space-separated) into a
    dictionary.

    Args:
        filename: path to the input file, where each line is
            "<key> <integer value>".

    Returns:
        dict mapping key (str) -> integer value.
    """
    opened = open(filename)
    dicti = {}
    for i in opened:
        i = i.strip()
        dicti[i.split(" ")[0]] = int(i.split(" ")[1])
    return dicti


def histogram(filename, numbucket):
    """
    Builds an equi-depth histogram over the (pattern -> count) data
    returned by openfile(), grouping sorted patterns into approximately
    `numbucket` buckets of roughly equal total count.

    Patterns are sorted lexicographically, then accumulated in order;
    once a running sum reaches the target bucket size (total values /
    numbucket), that pattern becomes a bucket endpoint and the running
    sum resets.

    Args:
        filename: path to the file passed to openfile().
        numbucket: target number of histogram buckets.

    Returns:
        A list of ((endpoint_pattern, endpoint_running_count),
        endpoint_own_count) tuples, one per bucket endpoint, in sorted
        pattern order.
    """
    data = openfile(filename)
    values = sum(data.values())
    bucketsize = values / numbucket
    tupl = list(data.items())
    tupl.sort()
    listem = []
    count = 0
    for i in range(len(tupl)):
        value = tupl[i][1]
        count += value
        if count >= bucketsize:
            newtupl = tuple(((tupl[i][0], count), int(tupl[i][1])))
            listem.append((newtupl))
            count = 0
        else:
            if i == len(tupl) - 1:
                if i < bucketsize:
                    newtupl = tuple(((tupl[i][0], count), int(tupl[i][1])))
                    listem.append((newtupl))
            continue
    return listem


def draw(filename, numbucket):
    """
    Computes the histogram for `filename` via histogram() and writes it
    out as a formatted table to "histogram.txt", with columns for the
    cumulative endpoint number, the endpoint pattern value, and the
    endpoint's own count.

    Args:
        filename: path to the file passed through to histogram().
        numbucket: target number of histogram buckets, passed through to
            histogram().

    Returns:
        None. Writes "histogram.txt" to the current working directory.
    """
    histfile = open("histogram.txt", "w")
    data = histogram(filename, numbucket)
    count = 0
    histfile.write("Endpoint Number" + "             " + "Enpoint Value" + "          " + "Endpoint Count")
    histfile.write("\n")
    histfile.write("--------------" + "              " + "-------------" + "          " + "--------------")
    histfile.write("\n")
    for i in data:
        count += i[0][1]
        histfile.write("    " + str(count) + "                       " + i[0][0] + "                       " + str(i[1]))
        histfile.write("\n")
    histfile.close()


draw("frequent_path_file", 2048)
