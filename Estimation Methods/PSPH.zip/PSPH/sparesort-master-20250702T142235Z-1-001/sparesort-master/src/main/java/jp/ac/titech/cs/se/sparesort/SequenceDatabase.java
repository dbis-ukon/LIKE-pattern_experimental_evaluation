
package jp.ac.titech.cs.se.sparesort;

import jp.ac.titech.cs.se.sparesort.bide.RecursiveBIDE;

import java.util.*;

public class SequenceDatabase<T> {

    private final List<T> prefix;

    private final List<Sequence<T>> sequences;

    private MiningStrategy<T> strategy;

    public SequenceDatabase() {
        this(null, new ArrayList<Sequence<T>>());
    }

    private SequenceDatabase(List<T> prefix, List<Sequence<T>> sequences) {
        this.prefix = prefix;
        this.sequences = sequences;
    }

    public SequenceDatabase<T> getProjectedDatabaseWithRespectTo(List<T> prefix) {
        List<Sequence<T>> projections = new ArrayList<Sequence<T>>();
        for (Sequence<T> sequence : sequences) {
            Sequence<T> ps = sequence.getProjectedSequenceWithRespectTo(prefix);

            if (ps != null) {
                projections.add(ps);
            }
        }
        return projections.isEmpty() ? null : new SequenceDatabase<T>(prefix,
                projections);
    }

    public List<Sequence<T>> getSequences() {
        return sequences;
    }

    public SequenceDatabase<T> addSequence(String id, List<T> events) {
        sequences.add(new Sequence<T>(id, events));
        return this;
    }

    public SequenceDatabase<T> addSequence(List<T> events) {
        return addSequence(String.valueOf(getSupportOfPrefix() + 1), events);
    }

    public SequenceDatabase<T> addSequence(T... events) {
        return addSequence(Arrays.asList(events));
    }

    public List<T> getPrefix() {
        return prefix;
    }

    public int getSupportOfPrefix() {
        return (sequences == null) ? 0 : sequences.size();
    }

    public MiningStrategy<T> getMiningStrategy() {
        if (strategy == null) {
            strategy = new RecursiveBIDE<T>();
        }
        return strategy;
    }

    public void setMiningStrategy(MiningStrategy<T> strategy) {
        this.strategy = strategy;
    }

    public Map<List<T>, Integer> mineFrequentClosedSequences(int minSup)
            throws Exception {
        final Map<List<T>, Integer> result = new HashMap<List<T>, Integer>();

        mineFrequentClosedSequences(minSup, new ResultHandler<T>() {
            public void handle(List<T> sequence, int frequency,
                               SequenceDatabase<T> sdb) {
                    result.put(sequence, frequency);



            }
        });

        return result;
    }

    public void mineFrequentClosedSequences(int minSup, ResultHandler<T> handler)
            throws Exception {
        getMiningStrategy().mineFrequentClosedSequences(this, minSup, handler);
    }


    public SortedMap<T, List<Integer>> getitems(int minSup) {
        SortedMap<T, List<Integer>> frequency1 = new TreeMap<T, List<Integer>>();
        SortedMap<T, Integer> frequency = new TreeMap<T, Integer>();
        SortedMap<T, Integer> frequencies = new TreeMap<T, Integer>();
        for (Sequence<T> sequence : sequences) {
            List<T> sequenceEvents=sequence.getEvents();
            if(sequenceEvents.size()>0){
                T a=sequenceEvents.get(0);
                if(frequency.containsKey(a)){
                    int s=frequency.get(a);
                    frequency.put(a, ++s);
                }
                else frequency.put(a,1);
            }
            for (T item : new HashSet<T>(sequenceEvents)) {
                int f = frequencies.containsKey(item) ? frequencies.get(item)
                        : 0;
                frequencies.put(item, ++f);
            }
        }
        for(T items: frequencies.keySet()){
            List<Integer> a1=new ArrayList<Integer>();
            if(!frequency1.containsKey(items)){
                if(frequencies.get(items)>=minSup){
                    a1.add(frequencies.get(items));
                    frequency1.put(items, a1) ;
                }

            }
        }
        for (T items: frequency.keySet()){
            List<Integer> a1=frequency1.get(items);
            if(frequency1.containsKey(items)){
                if(frequency.get(items)>=minSup){
                    a1.add(frequency.get(items));
                    frequency1.put(items,a1) ;
                }
            }
        }

        return frequency1;


    }
}