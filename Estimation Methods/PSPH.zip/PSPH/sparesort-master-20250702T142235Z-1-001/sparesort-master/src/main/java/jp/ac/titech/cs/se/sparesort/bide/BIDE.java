/*
 * Copyright (c) 2010-2012 Saeki Lab. at Tokyo Institute of Technology.
 * All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.ac.titech.cs.se.sparesort.bide;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

import jp.ac.titech.cs.se.sparesort.ResultHandler;
import jp.ac.titech.cs.se.sparesort.MiningStrategy;
import jp.ac.titech.cs.se.sparesort.Sequence;
import jp.ac.titech.cs.se.sparesort.SequenceDatabase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class BIDE<T> implements MiningStrategy<T> {
    protected static final Logger logger = LoggerFactory.getLogger(BIDE.class);
    protected List<List<T>> bide(SequenceDatabase<T> sdb, int minSup,
                                 ResultHandler<T> handler) {
        List<List<T>> prefixes = new ArrayList<List<T>>();
        List<T> prefix = sdb.getPrefix();
        SortedMap<T, List<Integer>> frequencie=sdb.getitems(minSup);
        if (prefix != null && backScan(sdb)) {return Collections.emptyList();}
        if (isPrefixClosed(sdb, frequencie)) {
            synchronized (handler) { handler.handle(prefix, sdb.getSupportOfPrefix(), sdb);}
        }
        for (Map.Entry<T, List<Integer>> entry : frequencie.entrySet()) {

            List<T> extendedPrefix = new ArrayList<T>();
            List<T> extendedPrefix1 = new ArrayList<T>();
            if (prefix != null) {
                extendedPrefix.addAll(prefix);
                extendedPrefix1.addAll(prefix);
            }
            List<Integer> values = entry.getValue();
            if(values.size()==2){//Entries have two types of frequencies
                if(values.get(0)==values.get(1)){//To eliminate pattern those have same frequencies
                    if(extendedPrefix1.size()>0)  {extendedPrefix1.add((T) "0");}
                    extendedPrefix1.add(entry.getKey());
                    prefixes.add(extendedPrefix1);
                }
                else {
                    extendedPrefix.add(entry.getKey());
                    prefixes.add(extendedPrefix);
                    if(extendedPrefix1.size()!=0) {
                        extendedPrefix1.add((T) "0");
                        prefixes.add(extendedPrefix1);
                    }
                    extendedPrefix1.add(entry.getKey());
                }
            }
            else {
                extendedPrefix.add(entry.getKey());
                prefixes.add(extendedPrefix);
            }
        }
        return prefixes;
    }


    protected boolean isPrefixClosed(SequenceDatabase<T> sdb,
                                     SortedMap<T, List<Integer>> frequencie1) {

        List<T> prefix = sdb.getPrefix();
        if (prefix == null) {
            return false;
        }
        int support = sdb.getSupportOfPrefix();

        for (Map.Entry<T,  List<Integer>> entry : frequencie1.entrySet()) {
            if (entry.getValue().get(0) == support) {
                return false; /* Found a forward extension item */
            }
        }
        if (!hasBackwardExtensionItem(sdb)) {


            return true;
        }
        return false;
    }

    protected boolean hasBackwardExtensionItem(SequenceDatabase<T> sdb) {

        List<T> prefix = sdb.getPrefix();
        List<T> prefix1 =new ArrayList<T>();
        for(T a:prefix) {
            if(a!="0"){prefix1.add(a);}
        }
        prefix_loop: for (int i = 0; i < (prefix1.size()); i++) {
            Set<T> intersection = null;
            for (Sequence<T> sequence : sdb.getSequences()) {
                List<T> mp_i = sequence.getMaximumPeriodOf(prefix1, i);
                if (mp_i == null || mp_i.isEmpty()) {
                    continue prefix_loop;
                }

                if (intersection == null) {
                    intersection = new HashSet<T>(mp_i);
                } else {
                    intersection.retainAll(mp_i);
                    if (intersection.isEmpty()) {
                        continue prefix_loop;
                    }
                }
            }



            return true;
        }
        return false;
    }

    protected boolean backScan(SequenceDatabase<T> sdb) {
        List<T> prefix = sdb.getPrefix();
        List<T> prefix1 =new ArrayList<T>();
        for(T a:prefix) {
            if(a!="0"){prefix1.add(a);}
        }
        prefix_loop: for (int i = 0; i < (prefix1.size()); i++) {
            Set<T> intersection = null;
            for (Sequence<T> sequence : sdb.getSequences()) {
                List<T> smp_i = sequence.getSemiMaximumPeriodOf(prefix1, i);
                if (smp_i == null || smp_i.isEmpty()) {
                    continue prefix_loop;
                }

                if (intersection == null) {
                    intersection = new HashSet<T>(smp_i);
                } else {
                    intersection.retainAll(smp_i);
                    if (intersection.isEmpty()) {
                        continue prefix_loop;
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static String toOrdinal(int i) {
        int mod = i % 10;
        return i + (mod == 1 ? "st" : mod == 2 ? "nd" : mod == 3 ? "rd" : "th");
    }

}
