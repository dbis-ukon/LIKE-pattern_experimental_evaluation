/*
 * Copyright (c) 2010-2012 Saeki Lab. at Tokyo Institute of Technology.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.ac.titech.cs.se.sparesort;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;



public class Main {

    public static void main(String[] args) throws Exception {

        System.out.println("Starting execution...");
        Runtime runtime = Runtime.getRuntime();

        // =========================
        // INPUT CONFIG
        // =========================
        String[] inputFiles = {
                "/home/mehmet/Documents/astrid-string-selectivity-master/datasets/imdb/companyname.csv",
                "/home/mehmet/Documents/astrid-string-selectivity-master/datasets/imdb/titlename.csv",
                "/home/mehmet/Documents/astrid-string-selectivity-master/datasets/imdb/keywords.csv"
        };

        String[] outputFiles = {
                "companyname_new.txt",
                "title_new.txt",
                "keywords_new.txt"
        };

        int[] minsups = {
                3525,   // for company
                37925,   // for actor
                2012    // for title
        };

        // =========================
        // PROCESS EACH FILE
        // =========================
        for (int f = 0; f < inputFiles.length; f++) {

            System.out.println("\nProcessing: " + inputFiles[f]);

            System.gc();
            long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();

            SequenceDatabase<String> sdb = new SequenceDatabase<>();

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(inputFiles[f]))
            );

            String line;
            int count = 0;

            while ((line = br.readLine()) != null) {
                line = line.trim();

                if (!line.isEmpty()) {
                    String[] arr = line.split("");
                    sdb.addSequence(Arrays.asList(arr));
                    count++;
                }
            }
            br.close();

            System.out.println("Loaded sequences: " + count);

            // =========================
            // MINING
            // =========================
            long startTime = System.currentTimeMillis();

            Map<List<String>, Integer> result =
                    sdb.mineFrequentClosedSequences(minsups[f]);

            long stopTime = System.currentTimeMillis();

            System.out.println("Computation Time: " + (stopTime - startTime) + " ms");

            // =========================
            // WRITE OUTPUT
            // =========================
            BufferedWriter bw = new BufferedWriter(
                    new FileWriter(outputFiles[f])
            );

            for (Map.Entry<List<String>, Integer> entry : result.entrySet()) {
                bw.write(entry.getKey() + ":" + entry.getValue());
                bw.newLine();
            }

            bw.close();

            // =========================
            // MEMORY LOG
            // =========================
            System.gc();
            Thread.sleep(100);

            long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();

            System.out.println("Memory increased: " +
                    (usedMemoryAfter - usedMemoryBefore) + " bytes");
        }

        System.out.println("\nAll files processed.");
    }
}










