from src.util import read_strings
import src.util as ut
import os
import yaml
import time
import torch
import pickle
from src.CLIQUE import CLIQUEestimator
import socket

hostname = socket.gethostname()
is_debug = False

if is_debug:
    input_config_path = "configs/CLIQUE/debug.yml"
else:
    input_config_path = "configs/CLIQUE/default.yml"
default_cfgs = yaml.safe_load(open(input_config_path))
abbr_dict = ut.get_common_abbr_dict()
choices_dict = ut.get_common_choices_dict()

parser = ut.get_parser(default_cfgs, abbr_dict, choices_dict)
args = parser.parse_args()


max_entry_ratio_dict = {
    "WIKI": 4.35,
    "IMDB": 1.675,
    "DBLP": 3.12,
    "GENE": 204.8,
    "AUTHOR": 4.8,
}
args.max_entry_ratio = max_entry_ratio_dict[args.data_name]
args.seed = ut.get_seed()

args.model_name = f"CLIQUE"
if args.packed:
    args.model_name += "-PACK"

if is_debug:
    args.tag = f"debug/" + args.tag

args.tag = os.path.join(args.tag, args.model_name)

N = args.N
PT = args.PT
data_name = args.data_name
seed = args.seed
n_epoch = args.n_epoch
ch_es = args.ch_es
rnn_hs = args.rnn_hs
pred_hs = args.pred_hs
p_test = args.p_test
p_val = args.p_val
p_train = args.p_train
n_pred_layer = args.n_pred_layer
bs = args.batch_size
lr = args.learning_rate
l2 = args.l2
patience = args.patience
packed = args.packed
min_coeff = args.min_coeff
bound_in = args.bound_in  # bool, whether the model takes bounds as input or not
mheader = args.mheader  # bool, whether the model has both prob and cprob headers or not
dynamicPT = args.dynamicPT
max_entry_ratio = args.max_entry_ratio
batch_norm = args.batch_norm
mark_pu = args.mark_pu
cal_size = args.cal_size
tag = args.tag
print(args)

last_flip = False

(
    db_path,
    model_config_path,
    model_path,
    est_path,
    est_time_path,
    stat_path,
) = ut.get_common_pathes_for_estimator(data_name, tag)

sw = ut.get_summary_writer(data_name, tag)
count_path = ut.get_count_path_for_HybridEstimator(
    data_name, PT, N, dynamicPT, max_entry_ratio
)

with open(model_config_path, "w") as f:
    yaml.safe_dump(vars(args), f)

db = read_strings(db_path)
n_db = len(db)
char_dict, n_special_char = ut.gen_char_dict(db)


char_dict, n_special_char, train_data, valid_data, test_data = ut.get_training_data(data_name, 0, p_test, p_val, p_train)

qc_dict = None
if packed:
    qc_dict = ut.get_qc_dict(data_name)


def packed_card(train_data, qc_dict, last_flip):
    output = []
    for query, card in train_data:
        query_cano = ut.canonicalize_like_query(query, last_flip)
        cards = []
        for query_len in range(1, len(query) + 1):
            sub_query = query_cano[:query_len]
            sub_query = ut.canonicalize_like_query(sub_query)
            # sub_query = query[:query_len]
            card = qc_dict[sub_query]
            cards.append(card)
        output.append([query, cards])
    return output


if packed:
    if mark_pu:
        train_data_old = train_data
        train_data = ut.add_prefix_augmented(train_data, qc_dict, last_flip)
    else:
        train_data_old = train_data
        train_data = packed_card(train_data, qc_dict, last_flip)

track_max = "track_max" in tag

model = CLIQUEestimator()
model.set_params(
    N,
    PT,
    seed,
    char_dict,
    ch_es,
    1,
    packed,
    rnn_hs,
    pred_hs,
    n_pred_layer,
    lr,
    l2,
    n_epoch,
    bs,
    patience,
    last_flip,
    sw,
    count_path,
    model_path,
    min_coeff,
    bound_in,
    mheader,
    dynamicPT,
    max_entry_ratio,
    batch_norm,
    mark_pu,
)


if cal_size:
    print("cal_size mode")
    model_size = ut.get_torch_model_size(model)
    model_size_hr = ut.human_readable_size(model_size)
    print(f"{model_size = }, {model_size_hr = }")
    hashtable, PTs, build_time = ut.getCachedPrunedExtendedNgramTableMaxEntry(
        data_name, N, max_entry_ratio
    )
    table_size = ut.get_pickle_size([hashtable, PTs])
    table_size_hr = ut.human_readable_size(table_size)

    print(f"{table_size = }, {table_size_hr = }")
    exit()
else:
    pass


torch.save(model.state_dict(), model_path)
build_time_count = model.build_count(data_name)
model_size = model.model_size()
model_size_hr = ut.human_readable_size(model_size)
print(f"{model_size = }, {model_size_hr = }")


build_time = model.build(data_name, db, train_data, valid_data, test_data, track_max)

print(f"{build_time = }")

test_queries, test_cards = list(zip(*test_data))

model.eval()
model.cpu()

start_time = time.time()
with torch.no_grad():
    test_estimations, test_estimation_times = model.estimate_latency_analysis(
        test_queries, to_cuda=False
    )
end_time = time.time()

est_time = end_time - start_time

print(f"{est_time = }")

print(f"{test_estimations[:5] = }")
print(f"{test_cards[:5] = }")

model_size = model.model_size()
print(f"{model_size = }")

q_errs = ut.mean_Q_error(test_cards, test_estimations, reduction="none")

ut.save_estimated_cards(test_queries, test_cards, test_estimations, est_path)
ut.save_estimation_times(
    test_queries, test_cards, test_estimations, test_estimation_times, est_time_path
)

# save stat (avg, q001, ..., q100, time) # train_time, test_time
ut.save_estimator_stat(stat_path, q_errs, build_time, est_time, model_size=model_size)
