#!/bin/bash

model=${1}
data=${2}

function RUN_ALG_CMD {
    if [[ "$model" == "LBS" ]]; then
        CMD="python main_LBS.py -d $data"
    elif [[ "$model" == "EST_S" ]]; then 
        CMD="python main_sampling.py -d $data"
    elif [[ "$model" == "EST_M" ]]; then 
        CMD="python main_sampling.py -d $data --is-greek"
    elif [[ "$model" == "EST_B" ]]; then 
        CMD="python main_sampling.py -d $data --is-greek --is-adapt"

    elif [[ "$model" == "Astrid" ]]; then 
        CMD="python main_Astrid.py -d $data"
    elif [[ "$model" == "E2E" ]]; then 
        CMD="python main_E2E.py -d $data"
    elif [[ "$model" == "DREAM" ]]; then 
        CMD="python main_DREAM.py -d $data"
    elif [[ "$model" == "CLIQUE" ]]; then 
        CMD="python main_CLIQUE.py -d $data"

    elif [[ "$model" == "Astrid-AUG" ]]; then 
        CMD="python main_Astrid.py -d $data --packed"
    elif [[ "$model" == "E2E-AUG" ]]; then 
        CMD="python main_E2E.py -d $data --packed"
    elif [[ "$model" == "DREAM-PACK" ]]; then 
        CMD="python main_DREAM.py -d $data --packed"
    elif [[ "$model" == "LPLM" ]]; then 
        CMD="python main_LPLM.py -d $data"
    elif [[ "$model" == "CLIQUE-PACK" ]]; then 
        CMD="python main_CLIQUE.py -d $data --packed"
    else
        CMD="echo model=$model is not supported"
    fi
    echo $CMD
    eval $CMD
}

RUN_ALG_CMD
