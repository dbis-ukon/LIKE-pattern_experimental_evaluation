# LEADER & CLIQUE

This repository implements training data generation algorithm (LEADER) and deep cardinality estimators (CLIQUE).

## Prerequisite

```bash
./setting.sh
make
# refer to sql/run_psql.sh to create postgres
```

## Generating train data (LEADER)
./main <alg> <data> <query> <is_aug>

* <alg>: the training data generation algorithm name (LEADER-S, LEADER-T, LEADER-SR, Naive, NaiveIndex)
* <data>: the dataset name (DBLP, GENE, AUTHOR, WIKI, IMDB)
* <query>: the query type (train, valid, test)
* <is_aug>: 0 or 1 to indicate whether the training data is augmented or not

### Examples
```bash
./main LEADER-S DBLP train 0 
./main LEADER-S DBLP valid 0 
./main LEADER-S DBLP test 0 
./main LEADER-S DBLP train 1 # prefix-aug training data 
```


## Training cardinality estimator (CLIQUE)
./model.sh <model> <data>
* <model>: the cardinality estimation model (LBS, EST_S, EST_M, EST_B, Astrid, E2E, DREAM, CLIQUE, Astrid-AUG, E2E-AUG, DREAM-PACK, LPLM, CLIQUE-PACK)
* <data>: the dataset name (DBLP, GENE, AUTHOR, WIKI, IMDB)

### Examples
```bash
./model.sh CLIQUE DBLP
./model.sh CLIQUE-PACK DBLP # using the packed learning method
```